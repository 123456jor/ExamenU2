# Arquitectura del sistema

## Descripción general

El sistema usa una arquitectura de microservicios orientada al dominio de un centro académico. Cada módulo se separa por responsabilidad y cuenta con despliegue independiente.

## Flujo de comunicación

1. El cliente web o móvil envía una solicitud HTTPS al `ms-ca-edge`.
2. El API Gateway enruta la petición al microservicio correspondiente.
3. Los servicios se registran en `ms-ca-discovery` para permitir descubrimiento dinámico.
4. La configuración externa se obtiene desde `ms-ca-config`.
5. Los microservicios de negocio se comunican entre sí mediante OpenFeign.
6. Cada microservicio posee su propia base de datos PostgreSQL.

## Diagrama Mermaid

```mermaid
flowchart LR
  C[Clientes Web/Móvil] -->|HTTPS| G[ms-ca-edge Gateway]
  CFG[ms-ca-config Config Server] -. configuración .-> G
  CFG -. configuración .-> P[ms-ca-personas]
  CFG -. configuración .-> R[ms-ca-recursos]
  CFG -. configuración .-> S[ms-ca-solicitudes]
  CFG -. configuración .-> A[ms-ca-agendamiento]
  CFG -. configuración .-> PE[ms-ca-penalidades]
  CFG -. configuración .-> M[ms-ca-mensajes]
  D[ms-ca-discovery Eureka] -. registro/descubrimiento .-> G
  D -. registro/descubrimiento .-> P
  D -. registro/descubrimiento .-> R
  D -. registro/descubrimiento .-> S
  D -. registro/descubrimiento .-> A
  D -. registro/descubrimiento .-> PE
  D -. registro/descubrimiento .-> M
  G --> P
  G --> R
  G --> S
  G --> A
  G --> PE
  G --> M
  S <-->|OpenFeign| R
  P --> DBP[(DB Personas)]
  R --> DBR[(DB Recursos)]
  S --> DBS[(DB Solicitudes)]
  A --> DBA[(DB Agendamiento)]
  PE --> DBPE[(DB Penalidades)]
  M --> DBM[(DB Mensajes)]
```

## Patrones aplicados

| Patrón | Aplicación |
|---|---|
| Database per Service | Cada microservicio tiene una base de datos propia. |
| API Gateway | Entrada única del sistema mediante `ms-ca-edge`. |
| Service Registry | Registro y descubrimiento con Eureka. |
| Externalized Configuration | Configuración centralizada con Config Server. |
| Cliente declarativo | Comunicación interna usando OpenFeign. |
