# Diferencias del diseño

Este proyecto no usa el mismo dominio de biblioteca. Se plantea como un sistema de Centro Académico para préstamos de recursos y reservas de ambientes.

## Cambios principales

| Diseño tipo biblioteca | Este diseño |
|---|---|
| Usuarios | Personas académicas |
| Libros | Recursos académicos: equipos, salas y laboratorios |
| Préstamos de libros | Solicitudes de préstamo de equipos |
| Reservas de libros | Agendamiento de ambientes o recursos |
| Multas | Penalidades académicas |
| Notificaciones | Mensajes institucionales |

Además, el microservicio Gateway se llama `ms-ca-edge`, el registro se llama `ms-ca-discovery` y los nombres de bases de datos, rutas, entidades y documentación usan terminología propia del nuevo dominio.
