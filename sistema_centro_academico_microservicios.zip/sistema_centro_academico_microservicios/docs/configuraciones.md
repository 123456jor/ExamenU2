# Configuraciones centralizadas

Las configuraciones se encuentran dentro de:

```text
ms-ca-config/src/main/resources/config-repo
```

Archivos disponibles:

- `ms-ca-edge.yml`
- `ms-ca-personas.yml`
- `ms-ca-recursos.yml`
- `ms-ca-solicitudes.yml`
- `ms-ca-agendamiento.yml`
- `ms-ca-penalidades.yml`
- `ms-ca-mensajes.yml`

## Propósito

El Config Server permite manejar propiedades externas sin modificar directamente el código de cada microservicio.

## Ambientes sugeridos

Para ampliar el proyecto se podrían agregar:

- `ms-ca-personas-dev.yml`
- `ms-ca-personas-test.yml`
- `ms-ca-personas-prod.yml`

De esa manera se separan credenciales, puertos y configuración según el entorno.
