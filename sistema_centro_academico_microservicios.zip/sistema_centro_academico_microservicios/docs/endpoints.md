# Endpoints principales

Las rutas pueden consumirse por el Gateway en `http://localhost:8090`.

## Personas

- `GET /personas`
- `GET /personas/{id}`
- `POST /personas`
- `POST /personas/login`

## Recursos

- `GET /recursos`
- `GET /recursos/{id}`
- `POST /recursos`
- `PUT /recursos/{id}/stock/descontar?cantidad=1`
- `PUT /recursos/{id}/stock/aumentar?cantidad=1`
- `GET /categorias`
- `POST /categorias`

## Solicitudes

- `GET /solicitudes`
- `POST /solicitudes`
- `PUT /solicitudes/{id}/devolver`

## Reservas

- `GET /reservas`
- `POST /reservas`
- `PUT /reservas/{id}/confirmar`
- `PUT /reservas/{id}/cancelar`

## Penalidades

- `GET /penalidades`
- `POST /penalidades`
- `PUT /penalidades/{id}/pagar`

## Mensajes

- `GET /mensajes`
- `POST /mensajes`
