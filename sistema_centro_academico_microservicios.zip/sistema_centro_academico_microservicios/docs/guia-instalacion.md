# Guía de instalación y ejecución

## 1. Requisitos

- Java 17 o superior.
- Maven 3.9 o superior.
- Docker Desktop iniciado.
- Puertos libres: `8761`, `8888`, `8090`, `8011` a `8016`, `5433` a `5438`.

## 2. Compilar el proyecto

Desde la carpeta raíz:

```bash
mvn clean package -DskipTests
```

## 3. Levantar todo con Docker Compose

```bash
docker compose up --build
```

Si aparece el error `unable to connect to the docker API`, abre Docker Desktop, espera que cargue y ejecuta:

```powershell
wsl --shutdown
docker info
docker compose up --build
```

## 4. Verificar servicios

- Eureka: `http://localhost:8761`
- Gateway: `http://localhost:8090`
- Config de personas: `http://localhost:8888/ms-ca-personas/default`

## 5. Orden lógico de inicio

1. `ms-ca-discovery`
2. `ms-ca-config`
3. `ms-ca-edge`
4. Bases de datos PostgreSQL
5. Microservicios de negocio

Docker Compose automatiza el levantamiento, pero la primera ejecución puede tardar porque descarga imágenes y construye los JAR.
