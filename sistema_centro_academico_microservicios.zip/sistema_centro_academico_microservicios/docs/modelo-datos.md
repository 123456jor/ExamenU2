# Modelo de datos por microservicio

## ms-ca-personas

Tabla `persona`:

| Campo | Tipo | Descripción |
|---|---|---|
| id | PK | Identificador interno. |
| nombres | Texto | Nombres de la persona. |
| apellidos | Texto | Apellidos de la persona. |
| correo | Único | Correo institucional. |
| clave | Texto | Clave de acceso simple para el ejercicio. |
| rol | Texto | ESTUDIANTE, DOCENTE o ADMINISTRADOR. |
| estado | Texto | ACTIVO o INACTIVO. |

## ms-ca-recursos

Tablas principales:

- `categoria_recurso`: clasifica equipos o ambientes.
- `recurso`: representa laptops, proyectores, salas, laboratorios u otros activos.

Índices recomendados:

- `IDX_recurso_codigo` sobre `codigoInterno`.
- `IDX_recurso_tipo` sobre `tipo`.
- `IDX_recurso_estado` sobre `estado`.

## ms-ca-solicitudes

Tablas principales:

- `solicitud_prestamo`: cabecera de préstamo.
- `detalle_solicitud`: recursos prestados en una solicitud.

Regla de negocio:

- Al registrar una solicitud, se descuenta stock del microservicio `ms-ca-recursos`.
- Al devolver una solicitud, se aumenta nuevamente el stock.

## ms-ca-agendamiento

Tablas principales:

- `reserva_ambiente`: registra reservas de ambientes o equipos.
- `historial_reserva`: registra cambios de estado.

Estados sugeridos:

- REGISTRADA
- CONFIRMADA
- CANCELADA
- VENCIDA

## ms-ca-penalidades

Tabla `penalidad`:

Registra multas o sanciones por retraso, deterioro del recurso o incumplimiento de condiciones.

## ms-ca-mensajes

Tabla `mensaje`:

Registra comunicaciones enviadas a estudiantes, docentes o responsables.

## Nota importante

No existen claves foráneas físicas entre bases de datos de distintos microservicios. Por ejemplo, `idPersona` en solicitudes es una referencia lógica al microservicio de personas.
