# Pruebas unitarias e integración

## Pruebas unitarias incluidas

Cada microservicio de negocio contiene al menos una prueba JUnit básica en `src/test/java`.

Ejecutar:

```bash
mvn test
```

## Prueba de integración manual

1. Levantar el sistema:

```bash
mvn clean package -DskipTests
docker compose up --build
```

2. Crear persona.
3. Crear recurso con stock disponible.
4. Crear solicitud de préstamo.
5. Verificar que el stock del recurso disminuya.
6. Devolver solicitud.
7. Verificar que el stock aumente.

Esta prueba valida la comunicación entre `ms-ca-solicitudes` y `ms-ca-recursos` mediante OpenFeign.
