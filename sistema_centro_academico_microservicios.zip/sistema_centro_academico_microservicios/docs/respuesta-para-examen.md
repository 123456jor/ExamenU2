# Respuesta lista para sustentar en examen

La arquitectura propuesta corresponde a un sistema de microservicios para un Centro Académico, donde cada servicio tiene una responsabilidad independiente. El sistema se divide en servicios administrativos y servicios de negocio.

El `ms-ca-config` funciona como servidor de configuración centralizada. Su propósito es evitar que cada microservicio tenga configuraciones repetidas, porque desde allí se administran puertos, conexiones a base de datos, rutas y parámetros generales.

El `ms-ca-discovery` utiliza Eureka Server y permite que los microservicios se registren y se descubran entre sí. Esto evita depender de direcciones IP fijas y facilita la escalabilidad.

El `ms-ca-edge` funciona como API Gateway. Es el único punto de entrada para clientes web o móviles. Desde allí se enrutan las solicitudes hacia personas, recursos, solicitudes de préstamo, reservas, penalidades y mensajes.

Los microservicios de negocio son `ms-ca-personas`, `ms-ca-recursos`, `ms-ca-solicitudes`, `ms-ca-agendamiento`, `ms-ca-penalidades` y `ms-ca-mensajes`. Cada uno maneja su propia lógica y su propia base de datos, aplicando el patrón Database per Service.

La comunicación interna se realiza mediante OpenFeign. Por ejemplo, cuando se registra una solicitud de préstamo, el microservicio `ms-ca-solicitudes` llama a `ms-ca-recursos` para descontar el stock disponible. Cuando el recurso es devuelto, se vuelve a aumentar el stock.

Esta arquitectura es adecuada porque permite independencia, bajo acoplamiento, escalabilidad y mantenimiento por separado. Además, con Docker Compose se puede levantar todo el ecosistema de servicios de manera ordenada y reproducible.
