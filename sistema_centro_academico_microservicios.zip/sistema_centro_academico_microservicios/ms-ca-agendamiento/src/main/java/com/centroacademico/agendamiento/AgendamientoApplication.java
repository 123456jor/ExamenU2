package com.centroacademico.agendamiento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients
public class AgendamientoApplication {
    public static void main(String[] args) {
        SpringApplication.run(AgendamientoApplication.class, args);
    }
}
