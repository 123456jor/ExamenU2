package com.centroacademico.agendamiento.controller;

import com.centroacademico.agendamiento.model.HistorialReserva;
import com.centroacademico.agendamiento.model.Reserva;
import com.centroacademico.agendamiento.repository.HistorialReservaRepository;
import com.centroacademico.agendamiento.repository.ReservaRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/reservas")
public class ReservaController {
    private final ReservaRepository reservaRepository;
    private final HistorialReservaRepository historialRepository;

    public ReservaController(ReservaRepository reservaRepository, HistorialReservaRepository historialRepository) {
        this.reservaRepository = reservaRepository;
        this.historialRepository = historialRepository;
    }

    @GetMapping public List<Reserva> listar() { return reservaRepository.findAll(); }
    @PostMapping public Reserva crear(@RequestBody Reserva reserva) {
        if (reserva.getEstado() == null) reserva.setEstado("REGISTRADA");
        return reservaRepository.save(reserva);
    }
    @PutMapping("/{id}/confirmar") public ResponseEntity<Reserva> confirmar(@PathVariable Long id) {
        return reservaRepository.findById(id).map(reserva -> cambiarEstado(reserva, "CONFIRMADA", "Confirmación de reserva"))
                .map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }
    @PutMapping("/{id}/cancelar") public ResponseEntity<Reserva> cancelar(@PathVariable Long id) {
        return reservaRepository.findById(id).map(reserva -> cambiarEstado(reserva, "CANCELADA", "Cancelación de reserva"))
                .map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }
    private Reserva cambiarEstado(Reserva reserva, String nuevoEstado, String observacion) {
        HistorialReserva historial = new HistorialReserva();
        historial.setIdReserva(reserva.getId());
        historial.setEstadoAnterior(reserva.getEstado());
        historial.setEstadoNuevo(nuevoEstado);
        historial.setFechaCambio(LocalDateTime.now());
        historial.setObservacion(observacion);
        historialRepository.save(historial);
        reserva.setEstado(nuevoEstado);
        return reservaRepository.save(reserva);
    }
}
