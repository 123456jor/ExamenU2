package com.centroacademico.agendamiento.repository;

import com.centroacademico.agendamiento.model.HistorialReserva;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HistorialReservaRepository extends JpaRepository<HistorialReserva, Long> {}
