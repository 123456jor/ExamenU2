package com.centroacademico.agendamiento.repository;

import com.centroacademico.agendamiento.model.Reserva;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReservaRepository extends JpaRepository<Reserva, Long> {}
