package com.centroacademico.agendamiento;

import com.centroacademico.agendamiento.model.Reserva;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ReservaEstadoTest {
    @Test
    void reservaPuedeCambiarEstado() {
        Reserva reserva = new Reserva();
        reserva.setEstado("REGISTRADA");
        assertEquals("REGISTRADA", reserva.getEstado());
    }
}
