package com.centroacademico.mensajes.controller;

import com.centroacademico.mensajes.model.Mensaje;
import com.centroacademico.mensajes.repository.MensajeRepository;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/mensajes")
public class MensajeController {
    private final MensajeRepository repository;
    public MensajeController(MensajeRepository repository) { this.repository = repository; }
    @GetMapping public List<Mensaje> listar() { return repository.findAll(); }
    @PostMapping public Mensaje enviar(@RequestBody Mensaje mensaje) {
        mensaje.setFechaEnvio(LocalDateTime.now());
        if (mensaje.getEstado() == null) mensaje.setEstado("ENVIADO");
        if (mensaje.getCanal() == null) mensaje.setCanal("EMAIL");
        return repository.save(mensaje);
    }
}
