package com.centroacademico.mensajes.repository;

import com.centroacademico.mensajes.model.Mensaje;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MensajeRepository extends JpaRepository<Mensaje, Long> {}
