package com.centroacademico.mensajes;

import com.centroacademico.mensajes.model.Mensaje;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class MensajeTest {
    @Test
    void mensajeTieneCanal() {
        Mensaje mensaje = new Mensaje();
        mensaje.setCanal("EMAIL");
        assertEquals("EMAIL", mensaje.getCanal());
    }
}
