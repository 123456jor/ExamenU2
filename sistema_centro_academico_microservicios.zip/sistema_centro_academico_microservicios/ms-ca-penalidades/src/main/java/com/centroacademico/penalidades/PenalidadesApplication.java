package com.centroacademico.penalidades;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients
public class PenalidadesApplication {
    public static void main(String[] args) {
        SpringApplication.run(PenalidadesApplication.class, args);
    }
}
