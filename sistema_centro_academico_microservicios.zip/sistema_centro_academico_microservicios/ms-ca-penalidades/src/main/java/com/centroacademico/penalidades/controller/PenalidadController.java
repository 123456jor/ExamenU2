package com.centroacademico.penalidades.controller;

import com.centroacademico.penalidades.model.Penalidad;
import com.centroacademico.penalidades.repository.PenalidadRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/penalidades")
public class PenalidadController {
    private final PenalidadRepository repository;
    public PenalidadController(PenalidadRepository repository) { this.repository = repository; }
    @GetMapping public List<Penalidad> listar() { return repository.findAll(); }
    @PostMapping public Penalidad crear(@RequestBody Penalidad penalidad) {
        penalidad.setFechaRegistro(LocalDateTime.now());
        if (penalidad.getEstado() == null) penalidad.setEstado("PENDIENTE");
        return repository.save(penalidad);
    }
    @PutMapping("/{id}/pagar") public ResponseEntity<Penalidad> pagar(@PathVariable Long id) {
        return repository.findById(id).map(p -> { p.setEstado("PAGADA"); return ResponseEntity.ok(repository.save(p)); })
                .orElse(ResponseEntity.notFound().build());
    }
}
