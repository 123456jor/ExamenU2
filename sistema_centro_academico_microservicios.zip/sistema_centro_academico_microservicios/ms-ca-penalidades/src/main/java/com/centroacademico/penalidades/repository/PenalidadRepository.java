package com.centroacademico.penalidades.repository;

import com.centroacademico.penalidades.model.Penalidad;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PenalidadRepository extends JpaRepository<Penalidad, Long> {}
