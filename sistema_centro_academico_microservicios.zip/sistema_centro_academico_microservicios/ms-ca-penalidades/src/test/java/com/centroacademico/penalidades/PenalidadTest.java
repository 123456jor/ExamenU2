package com.centroacademico.penalidades;

import com.centroacademico.penalidades.model.Penalidad;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.*;

class PenalidadTest {
    @Test
    void montoNoDebeSerNegativo() {
        Penalidad penalidad = new Penalidad();
        penalidad.setMonto(new BigDecimal("5.00"));
        assertTrue(penalidad.getMonto().compareTo(BigDecimal.ZERO) > 0);
    }
}
