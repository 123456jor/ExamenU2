package com.centroacademico.personas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients
public class PersonasApplication {
    public static void main(String[] args) {
        SpringApplication.run(PersonasApplication.class, args);
    }
}
