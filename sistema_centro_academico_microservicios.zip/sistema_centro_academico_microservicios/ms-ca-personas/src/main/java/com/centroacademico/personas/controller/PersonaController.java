package com.centroacademico.personas.controller;

import com.centroacademico.personas.dto.LoginRequest;
import com.centroacademico.personas.dto.LoginResponse;
import com.centroacademico.personas.model.Persona;
import com.centroacademico.personas.repository.PersonaRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/personas")
public class PersonaController {
    private final PersonaRepository repository;

    public PersonaController(PersonaRepository repository) {
        this.repository = repository;
    }

    @GetMapping
    public List<Persona> listar() {
        return repository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Persona> obtener(@PathVariable Long id) {
        return repository.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Persona registrar(@RequestBody Persona persona) {
        if (persona.getEstado() == null) persona.setEstado("ACTIVO");
        if (persona.getRol() == null) persona.setRol("ESTUDIANTE");
        return repository.save(persona);
    }

    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@RequestBody LoginRequest request) {
        return repository.findByCorreo(request.getCorreo())
                .filter(p -> p.getClave() != null && p.getClave().equals(request.getClave()))
                .map(p -> ResponseEntity.ok(new LoginResponse("token-ca-" + p.getId(), "Acceso correcto", p.getRol())))
                .orElse(ResponseEntity.status(401).body(new LoginResponse(null, "Credenciales inválidas", null)));
    }
}
