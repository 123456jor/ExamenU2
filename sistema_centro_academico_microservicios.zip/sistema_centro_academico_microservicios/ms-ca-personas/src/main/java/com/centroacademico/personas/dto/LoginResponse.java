package com.centroacademico.personas.dto;

public class LoginResponse {
    private String token;
    private String mensaje;
    private String rol;

    public LoginResponse(String token, String mensaje, String rol) {
        this.token = token;
        this.mensaje = mensaje;
        this.rol = rol;
    }

    public String getToken() { return token; }
    public String getMensaje() { return mensaje; }
    public String getRol() { return rol; }
}
