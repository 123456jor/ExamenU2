package com.centroacademico.personas;

import com.centroacademico.personas.model.Persona;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class PersonaNombreTest {
    @Test
    void debeAsignarCorreoInstitucional() {
        Persona persona = new Persona();
        persona.setCorreo("ana@instituto.edu");
        assertTrue(persona.getCorreo().contains("@"));
    }
}
