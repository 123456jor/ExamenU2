package com.centroacademico.recursos.controller;

import com.centroacademico.recursos.model.Categoria;
import com.centroacademico.recursos.repository.CategoriaRepository;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/categorias")
public class CategoriaController {
    private final CategoriaRepository repository;
    public CategoriaController(CategoriaRepository repository) { this.repository = repository; }
    @GetMapping public List<Categoria> listar() { return repository.findAll(); }
    @PostMapping public Categoria crear(@RequestBody Categoria categoria) { return repository.save(categoria); }
}
