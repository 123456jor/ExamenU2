package com.centroacademico.recursos.controller;

import com.centroacademico.recursos.model.Recurso;
import com.centroacademico.recursos.repository.RecursoRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/recursos")
public class RecursoController {
    private final RecursoRepository repository;
    public RecursoController(RecursoRepository repository) { this.repository = repository; }

    @GetMapping public List<Recurso> listar() { return repository.findAll(); }
    @GetMapping("/{id}") public ResponseEntity<Recurso> obtener(@PathVariable Long id) {
        return repository.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }
    @PostMapping public Recurso crear(@RequestBody Recurso recurso) {
        if (recurso.getEstado() == null) recurso.setEstado("DISPONIBLE");
        if (recurso.getStockDisponible() == null) recurso.setStockDisponible(recurso.getStockTotal());
        return repository.save(recurso);
    }
    @PutMapping("/{id}/stock/descontar")
    public ResponseEntity<Recurso> descontar(@PathVariable Long id, @RequestParam Integer cantidad) {
        return repository.findById(id).map(recurso -> {
            int disponible = recurso.getStockDisponible() == null ? 0 : recurso.getStockDisponible();
            if (disponible < cantidad) return ResponseEntity.badRequest().body(recurso);
            recurso.setStockDisponible(disponible - cantidad);
            return ResponseEntity.ok(repository.save(recurso));
        }).orElse(ResponseEntity.notFound().build());
    }
    @PutMapping("/{id}/stock/aumentar")
    public ResponseEntity<Recurso> aumentar(@PathVariable Long id, @RequestParam Integer cantidad) {
        return repository.findById(id).map(recurso -> {
            int disponible = recurso.getStockDisponible() == null ? 0 : recurso.getStockDisponible();
            recurso.setStockDisponible(disponible + cantidad);
            return ResponseEntity.ok(repository.save(recurso));
        }).orElse(ResponseEntity.notFound().build());
    }
}
