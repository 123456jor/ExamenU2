package com.centroacademico.recursos.model;

import jakarta.persistence.*;

@Entity
@Table(name = "recurso", uniqueConstraints = @UniqueConstraint(columnNames = "codigoInterno"))
public class Recurso {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String codigoInterno;
    private String nombre;
    private String tipo;
    private String ubicacion;
    private String estado;
    private Integer stockTotal;
    private Integer stockDisponible;

    @ManyToOne
    @JoinColumn(name = "id_categoria")
    private Categoria categoria;

    public Recurso() {}
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getCodigoInterno() { return codigoInterno; }
    public void setCodigoInterno(String codigoInterno) { this.codigoInterno = codigoInterno; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }
    public String getUbicacion() { return ubicacion; }
    public void setUbicacion(String ubicacion) { this.ubicacion = ubicacion; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    public Integer getStockTotal() { return stockTotal; }
    public void setStockTotal(Integer stockTotal) { this.stockTotal = stockTotal; }
    public Integer getStockDisponible() { return stockDisponible; }
    public void setStockDisponible(Integer stockDisponible) { this.stockDisponible = stockDisponible; }
    public Categoria getCategoria() { return categoria; }
    public void setCategoria(Categoria categoria) { this.categoria = categoria; }
}
