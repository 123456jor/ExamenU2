package com.centroacademico.recursos.repository;

import com.centroacademico.recursos.model.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoriaRepository extends JpaRepository<Categoria, Long> {}
