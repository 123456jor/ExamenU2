package com.centroacademico.recursos.repository;

import com.centroacademico.recursos.model.Recurso;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RecursoRepository extends JpaRepository<Recurso, Long> {}
