package com.centroacademico.recursos;

import com.centroacademico.recursos.model.Recurso;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class RecursoStockTest {
    @Test
    void recursoDebeTenerStockDisponible() {
        Recurso recurso = new Recurso();
        recurso.setStockDisponible(3);
        assertEquals(3, recurso.getStockDisponible());
    }
}
