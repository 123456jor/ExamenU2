package com.centroacademico.solicitudes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients
public class SolicitudesApplication {
    public static void main(String[] args) {
        SpringApplication.run(SolicitudesApplication.class, args);
    }
}
