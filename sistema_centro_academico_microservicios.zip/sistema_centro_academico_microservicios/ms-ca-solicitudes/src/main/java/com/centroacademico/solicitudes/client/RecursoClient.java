package com.centroacademico.solicitudes.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "ms-ca-recursos")
public interface RecursoClient {
    @PutMapping("/recursos/{id}/stock/descontar")
    void descontarStock(@PathVariable("id") Long id, @RequestParam("cantidad") Integer cantidad);

    @PutMapping("/recursos/{id}/stock/aumentar")
    void aumentarStock(@PathVariable("id") Long id, @RequestParam("cantidad") Integer cantidad);
}
