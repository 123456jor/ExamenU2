package com.centroacademico.solicitudes.controller;

import com.centroacademico.solicitudes.model.SolicitudPrestamo;
import com.centroacademico.solicitudes.service.SolicitudService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/solicitudes")
public class SolicitudController {
    private final SolicitudService service;
    public SolicitudController(SolicitudService service) { this.service = service; }
    @GetMapping public List<SolicitudPrestamo> listar() { return service.listar(); }
    @PostMapping public SolicitudPrestamo registrar(@RequestBody SolicitudPrestamo solicitud) { return service.registrar(solicitud); }
    @PutMapping("/{id}/devolver") public SolicitudPrestamo devolver(@PathVariable Long id) { return service.devolver(id); }
}
