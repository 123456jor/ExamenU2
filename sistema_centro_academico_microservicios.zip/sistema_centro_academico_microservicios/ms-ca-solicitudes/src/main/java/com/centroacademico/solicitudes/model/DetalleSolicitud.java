package com.centroacademico.solicitudes.model;

import jakarta.persistence.*;

@Entity
@Table(name = "detalle_solicitud")
public class DetalleSolicitud {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long idRecurso;
    private Integer cantidad;
    private String observacion;

    public DetalleSolicitud() {}
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getIdRecurso() { return idRecurso; }
    public void setIdRecurso(Long idRecurso) { this.idRecurso = idRecurso; }
    public Integer getCantidad() { return cantidad; }
    public void setCantidad(Integer cantidad) { this.cantidad = cantidad; }
    public String getObservacion() { return observacion; }
    public void setObservacion(String observacion) { this.observacion = observacion; }
}
