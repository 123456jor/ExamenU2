package com.centroacademico.solicitudes.repository;

import com.centroacademico.solicitudes.model.SolicitudPrestamo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SolicitudRepository extends JpaRepository<SolicitudPrestamo, Long> {}
