package com.centroacademico.solicitudes.service;

import com.centroacademico.solicitudes.client.RecursoClient;
import com.centroacademico.solicitudes.model.DetalleSolicitud;
import com.centroacademico.solicitudes.model.SolicitudPrestamo;
import com.centroacademico.solicitudes.repository.SolicitudRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class SolicitudService {
    private final SolicitudRepository repository;
    private final RecursoClient recursoClient;

    public SolicitudService(SolicitudRepository repository, RecursoClient recursoClient) {
        this.repository = repository;
        this.recursoClient = recursoClient;
    }

    public List<SolicitudPrestamo> listar() {
        return repository.findAll();
    }

    public SolicitudPrestamo registrar(SolicitudPrestamo solicitud) {
        solicitud.setFechaSolicitud(LocalDate.now());
        if (solicitud.getEstado() == null) solicitud.setEstado("ACTIVA");
        for (DetalleSolicitud detalle : solicitud.getDetalles()) {
            recursoClient.descontarStock(detalle.getIdRecurso(), detalle.getCantidad());
        }
        return repository.save(solicitud);
    }

    public SolicitudPrestamo devolver(Long id) {
        SolicitudPrestamo solicitud = repository.findById(id).orElseThrow();
        if (!"DEVUELTA".equalsIgnoreCase(solicitud.getEstado())) {
            solicitud.setFechaDevolucion(LocalDate.now());
            solicitud.setEstado("DEVUELTA");
            for (DetalleSolicitud detalle : solicitud.getDetalles()) {
                recursoClient.aumentarStock(detalle.getIdRecurso(), detalle.getCantidad());
            }
        }
        return repository.save(solicitud);
    }
}
