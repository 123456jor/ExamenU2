package com.centroacademico.solicitudes;

import com.centroacademico.solicitudes.model.DetalleSolicitud;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class DetalleSolicitudTest {
    @Test
    void cantidadDebeSerMayorACero() {
        DetalleSolicitud detalle = new DetalleSolicitud();
        detalle.setCantidad(1);
        assertTrue(detalle.getCantidad() > 0);
    }
}
